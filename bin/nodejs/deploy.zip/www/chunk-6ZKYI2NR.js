import{b as a,c as b}from"./chunk-JZGUXWEV.js";import"./chunk-SBFMPD7K.js";export{a as GESTURE_CONTROLLER,b as createGesture};
