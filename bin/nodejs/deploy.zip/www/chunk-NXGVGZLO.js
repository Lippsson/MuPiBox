import{b as a,c as b}from"./chunk-BBQNTFN7.js";import"./chunk-2R6CW7ES.js";export{a as GESTURE_CONTROLLER,b as createGesture};
